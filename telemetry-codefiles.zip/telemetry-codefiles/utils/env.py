from dotenv import load_dotenv  # type: ignore
import os

def load_env() -> None:
    """
    Load environment variables from the .env file and validate required keys.
    """
    load_dotenv()

    required_vars = [
        "AZURE_OPENAI_ENDPOINT",
        "AZURE_OPENAI_API_KEY",
        "AZURE_OPENAI_RESPONSES_DEPLOYMENT_NAME",
        "AZURE_OPENAI_API_VERSION",
    ]
    
    # Observability variables (optional but recommended)
    observability_vars = [
        "APPLICATIONINSIGHTS_CONNECTION_STRING",
        "ENABLE_OTEL",
        "ENABLE_SENSITIVE_DATA"
    ]

    missing = [var for var in required_vars if not os.getenv(var)]
    if missing:
        raise RuntimeError(f"Missing required environment variables: {', '.join(missing)}")
    
    # Check observability configuration
    missing_observability = [var for var in observability_vars if not os.getenv(var)]
    if missing_observability:
        print(f"⚠️  Optional observability variables not set: {', '.join(missing_observability)}")
        print("📊 Consider setting these for enhanced monitoring and tracing in Application Insights")
