import os
import asyncio
from azure.ai.projects.aio import AIProjectClient
from agent_framework import ChatAgent
from agent_framework.azure import AzureAIAgentClient
from azure.identity.aio import AzureCliCredential
# Agent Framework Observability imports
from agent_framework.observability import get_tracer
from opentelemetry.trace import SpanKind

async def build_planner_agent():
    """Build or reuse persistent planner agent"""
    credential = AzureCliCredential()
    
    async with AIProjectClient(
        endpoint=os.getenv("AZURE_AI_PROJECT_ENDPOINT"), 
        credential=credential
    ) as project_client:
        
        # Try to find existing agent first
        agent_name = "Enterprise-PlannerAgent"
        try:
            agents = project_client.agents.list_agents()
            async for agent in agents:
                if agent.name == agent_name:
                    # Return existing persistent agent
                    return ChatAgent(
                        chat_client=AzureAIAgentClient(
                            async_credential=credential,
                            agent_id=agent.id,
                            project_endpoint=os.getenv("AZURE_AI_PROJECT_ENDPOINT"),
                            model_deployment_name=os.getenv("AZURE_AI_MODEL_DEPLOYMENT_NAME")
                        ),
                        instructions="You are an intelligent routing agent."
                    )
        except Exception:
            pass  # Continue to create new agent if listing fails
        
        # Create new persistent agent if not found
        created_agent = await project_client.agents.create_agent(
            model=os.getenv("AZURE_AI_MODEL_DEPLOYMENT_NAME"),
            name=agent_name,
            instructions=(
                "You are an intelligent routing agent. Analyze user queries and route them to the appropriate specialist. "
                "Available specialists:\n"
                "- HR: Employee policies, leave, benefits, working hours, performance, hiring\n"
                "- FINANCE: Reimbursements, expenses, budgets, travel costs, meal allowances, equipment purchases\n"
                "- COMPLIANCE: GDPR, data privacy, regulatory requirements, legal compliance, audits\n\n"
                "Return exactly one word: HR, FINANCE, or COMPLIANCE. "
                "Consider keywords like: money, cost, budget, reimburse, expense, payment, allowance → FINANCE\n"
                "Keywords like: leave, sick, vacation, policy, employee, benefits → HR\n"
                "Keywords like: GDPR, privacy, compliance, legal, audit, regulation → COMPLIANCE"
            )
        )
        
        # Return persistent agent wrapped in ChatAgent
        return ChatAgent(
            chat_client=AzureAIAgentClient(
                async_credential=credential,
                agent_id=created_agent.id,
                project_endpoint=os.getenv("AZURE_AI_PROJECT_ENDPOINT"),
                model_deployment_name=os.getenv("AZURE_AI_MODEL_DEPLOYMENT_NAME")
            ),
            instructions="You are an intelligent routing agent."
        )

async def classify_target(planner_agent, user_query: str) -> str:
    tracer = get_tracer()
    with tracer.start_as_current_span(
        name="planner_agent_classification",
        kind=SpanKind.INTERNAL,
        attributes={
            "planner.query": user_query,
            "planner.agent": "Enterprise-PlannerAgent"
        }
    ) as classification_span:
        
        result = await planner_agent.run(
            "Analyze and route this query:\n\n"
            f"User query: {user_query}\n\n"
            "Return exactly one word: HR, FINANCE, or COMPLIANCE."
        )
        # Extract the text content from the AgentRunResponse object
        text = str(result).strip().lower()
        classification_span.set_attribute("planner.raw_response", text)
        
        # Advanced classification with fallback logic
        target = None
        classification_method = "agent_response"
        
        if "finance" in text or "financial" in text:
            target = "FINANCE"
        elif "hr" in text or "human" in text:
            target = "HR"
        elif "compliance" in text or "legal" in text:
            target = "COMPLIANCE"
        else:
            # Fallback keyword analysis if agent response is unclear
            classification_method = "keyword_fallback"
            query_lower = user_query.lower()
            finance_keywords = ["reimburs", "expense", "cost", "budget", "money", "payment", "allowance", "travel", "meal", "flight", "hotel"]
            hr_keywords = ["leave", "sick", "vacation", "employee", "benefit", "policy", "hire", "performance", "work"]
            compliance_keywords = ["gdpr", "privacy", "compliance", "legal", "audit", "regulation", "data protection"]
            
            finance_score = sum(1 for keyword in finance_keywords if keyword in query_lower)
            hr_score = sum(1 for keyword in hr_keywords if keyword in query_lower)
            compliance_score = sum(1 for keyword in compliance_keywords if keyword in query_lower)
            
            classification_span.set_attribute("planner.finance_score", finance_score)
            classification_span.set_attribute("planner.hr_score", hr_score)
            classification_span.set_attribute("planner.compliance_score", compliance_score)
            
            if finance_score > hr_score and finance_score > compliance_score:
                target = "FINANCE"
            elif hr_score > compliance_score:
                target = "HR"
            else:
                target = "COMPLIANCE"
        
        classification_span.set_attribute("planner.target", target)
        classification_span.set_attribute("planner.method", classification_method)
        
        return target
