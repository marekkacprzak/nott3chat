import os
import asyncio
from azure.ai.projects.aio import AIProjectClient
from agent_framework import ChatAgent
from agent_framework.azure import AzureAIAgentClient
from azure.identity.aio import AzureCliCredential

async def build_hr_agent():
    """Build or reuse persistent HR agent"""
    credential = AzureCliCredential()
    
    async with AIProjectClient(
        endpoint=os.getenv("AZURE_AI_PROJECT_ENDPOINT"), 
        credential=credential
    ) as project_client:
        
        # Try to find existing agent first
        agent_name = "Enterprise-HRAgent"
        try:
            agents = project_client.agents.list_agents()
            async for agent in agents:
                if agent.name == agent_name:
                    # Return existing persistent agent
                    return ChatAgent(
                        chat_client=AzureAIAgentClient(
                            async_credential=credential,
                            agent_id=agent.id,
                            project_endpoint=os.getenv("AZURE_AI_PROJECT_ENDPOINT"),
                            model_deployment_name=os.getenv("AZURE_AI_MODEL_DEPLOYMENT_NAME")
                        ),
                        instructions="You are an expert HR policy specialist."
                    )
        except Exception:
            pass  # Continue to create new agent if listing fails
        
        # Create new persistent agent if not found
        created_agent = await project_client.agents.create_agent(
            model=os.getenv("AZURE_AI_MODEL_DEPLOYMENT_NAME"),
            name=agent_name,
        instructions=(
            "You are an expert HR policy specialist with deep knowledge of employment law and best practices. "
            "Answer questions about:\n"
            "- Leave policies (sick, vacation, parental, bereavement)\n"
            "- Employee benefits (health insurance, retirement, wellness programs)\n" 
            "- Performance management and reviews\n"
            "- Hiring, onboarding, and termination procedures\n"
            "- Working hours, overtime, and flexible work arrangements\n"
            "- Employee relations and conflict resolution\n"
            "- Training and development programs\n\n"
            "When provided CONTEXT, prefer it as the primary source. "
            "If the user asks to create a ticket (phrases like \"create a ticket\", \"submit a leave request\", \"open a support ticket\"), output a structured block starting with:\n"
            "CREATE_TICKET\n"
            "Subject: <one-line subject>\n"
            "Body: <detailed description>\n"
            "Tags: tag1,tag2 (optional)\n"
            "Email: john.doe@example.com (optional)\n"
            "Name: John Doe (optional)\n"
            "Return only the CREATE_TICKET block when requesting a ticket; do not call any APIs yourself.\n\n"
            "Provide specific, actionable guidance with policy references where applicable. "
            "Be empathetic and professional in your responses."
            )
        )
        
        # Return persistent agent wrapped in ChatAgent
        return ChatAgent(
            chat_client=AzureAIAgentClient(
                async_credential=credential,
                agent_id=created_agent.id,
                project_endpoint=os.getenv("AZURE_AI_PROJECT_ENDPOINT"),
                model_deployment_name=os.getenv("AZURE_AI_MODEL_DEPLOYMENT_NAME")
            ),
            instructions="You are an expert HR policy specialist."
        )
